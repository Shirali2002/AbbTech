package hw2;

public class Main {

    public static void main(String[] args) {
//        ShootingAtTheSquareSimple shooting = new ShootingAtTheSquareSimple();
//        shooting.start();

//        ShootingAtTheSquareAdvanced shooting = new ShootingAtTheSquareAdvanced();
//        shooting.start();


    }
}
